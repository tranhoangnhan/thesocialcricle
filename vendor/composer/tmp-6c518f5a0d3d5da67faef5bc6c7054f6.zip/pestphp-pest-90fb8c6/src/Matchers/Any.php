<?php

declare(strict_types=1);

namespace Pest\Matchers;

/**
 * @internal
 */
final class Any
{
}
